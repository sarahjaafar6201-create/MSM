// MSM — استقبال طلبات الانضمام وقبولها/رفضها من البريد (Cloudflare Worker + KV + Resend)
const enc = new TextEncoder();
const sha = async (s) => [...new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s)))].map((b) => b.toString(16).padStart(2, "0")).join("");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ID = /^[a-f0-9-]{36}$/;

async function mail(env, to, subject, html, replyTo) {
  try {
    const r = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: "Bearer " + env.RESEND_API_KEY, "Content-Type": "application/json" }, body: JSON.stringify({ from: env.FROM_EMAIL || "MSM <onboarding@resend.dev>", to: [to], subject, html, reply_to: replyTo }) });
    return r.ok;
  } catch (e) { return false; }
}
const wrap = (h) => '<div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;max-width:560px;line-height:1.8">' + h + "</div>";
const page = (body) => new Response('<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><meta name="referrer" content="no-referrer"><title>MSM</title><style>body{font-family:Tahoma,Arial,sans-serif;max-width:480px;margin:40px auto;padding:0 16px;line-height:1.8;text-align:center}button{padding:12px 24px;border:0;border-radius:8px;color:#fff;font-size:1rem;cursor:pointer}</style></head><body>' + body + "</body></html>", { headers: { "content-type": "text/html; charset=utf-8" } });

async function load(env, id, t) {
  if (!ID.test(String(id))) return null;
  const raw = await env.KV.get("app:" + id); if (!raw) return null;
  const r = JSON.parse(raw);
  return r.tokenHash === (await sha(String(t || ""))) ? r : null;
}

async function submit(b, env, origin) {
  if (b.website) return { ok: true };
  const f = (k, n) => String(b[k] ?? "").trim().slice(0, n);
  const a = { shop: f("bname", 120), owner: f("name", 120), phone: f("phone", 30), email: f("email", 160).toLowerCase(), category: f("category", 60), desc: f("desc", 1000), message: f("msg", 1500), mode: f("mode", 40), fee: Math.max(0, Number(b.fee) || 0), city: f("city", 100), social: f("social", 200), catKey: f("cat", 10), modeKey: f("modeKey", 10) };
  if (!a.shop || !a.owner || !a.phone || !a.desc || !a.message || !/^\S+@\S+\.\S+$/.test(a.email)) return { ok: false, error: "invalid" };
  const rl = "rl:" + a.email, n = parseInt((await env.KV.get(rl)) || "0", 10);
  if (n >= 3) return { ok: false, error: "rate" };
  await env.KV.put(rl, String(n + 1), { expirationTtl: 3600 });
  const id = crypto.randomUUID(), token = crypto.randomUUID() + crypto.randomUUID().replace(/-/g, "");
  await env.KV.put("app:" + id, JSON.stringify({ id, tokenHash: await sha(token), created: new Date().toISOString(), status: "pending", ...a }));
  await env.KV.put("em:" + a.email, id);
  const base = origin + "?id=" + id + "&t=" + token + "&a=";
  const rows = [["اسم المتجر", a.shop], ["اسم صاحب المتجر", a.owner], ["رقم الهاتف", a.phone], ["البريد الإلكتروني", a.email], ["تصنيف المتجر", a.category], ["نبذة عن المتجر", a.desc], ["رسالة طلب الانضمام", a.message], ["الخدمة", a.mode], ["رسوم التوصيل", String(a.fee)], ["المنطقة", a.city], ["الحساب / الرابط", a.social]];
  const html = wrap("<h2>طلب انضمام جديد إلى MSM</h2><table style=\"width:100%;border-collapse:collapse\">" + rows.filter((r) => r[1]).map((r) => '<tr><td style="padding:6px;border-bottom:1px solid #eee;color:#666;width:34%">' + r[0] + '</td><td style="padding:6px;border-bottom:1px solid #eee"><b>' + esc(r[1]) + "</b></td></tr>").join("") + '</table><p style="margin-top:20px"><a href="' + base + 'accept" style="background:#1f8a70;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:bold">✅ قبول الطلب (Accept)</a>&nbsp;&nbsp;<a href="' + base + 'reject" style="background:#e8576b;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:bold">❌ رفض الطلب (Reject)</a></p><p style="color:#888;font-size:12px">الرابط يفتح صفحة تأكيد، ولا يُنفَّذ القرار إلا بعد الضغط على زر التأكيد. لا تشارك هذه الرسالة.</p>');
  await mail(env, env.ADMIN_EMAIL, "طلب انضمام جديد: " + a.shop, html, a.email);
  return { ok: true, id };
}

// يعرض للمتقدّم حالة طلبه فقط (بدون هاتف أو رسالة)
async function status(b, env) {
  const em = String(b.email || "").trim().toLowerCase(), id = await env.KV.get("em:" + em);
  const raw = id && (await env.KV.get("app:" + id));
  if (!raw) return { ok: true, status: null };
  const r = JSON.parse(raw), res = { ok: true, status: r.status };
  if (r.status === "accepted") await ensureBrand(env, r);
  if (r.status === "accepted") res.brand = { shop: r.shop, desc: r.desc, fee: r.fee, catKey: r.catKey, modeKey: r.modeKey };
  return res;
}

async function decide(b, env) {
  const r = await load(env, b.id, b.t); if (!r) return { ok: false, error: "invalid" };
  if (r.status !== "pending") return { ok: true, status: r.status, already: true };
  const acc = b.a === "accept";
  r.status = acc ? "accepted" : "rejected"; r.decided = new Date().toISOString();
  await env.KV.put("app:" + r.id, JSON.stringify(r));
  if (acc) await ensureBrand(env, r);
  const body = acc
    ? wrap("<h2>مبروك! تم قبول متجرك «" + esc(r.shop) + "»</h2><p>سجّل الدخول إلى الموقع ببريدك <b>" + esc(r.email) + "</b> ثم اختر «أنا صاحب براند»، وستفتح لك لوحة متجرك لإضافة المنتجات واستقبال الطلبات.</p>" + (env.SITE_URL ? '<p><a href="' + esc(env.SITE_URL) + '">' + esc(env.SITE_URL) + "</a></p>" : ""))
    : wrap("<p>نعتذر، لم نتمكن من قبول طلب انضمام «" + esc(r.shop) + "» حالياً. يمكنك تعديل بياناتك وإعادة الإرسال من الموقع.</p>");
  const notified = await mail(env, r.email, acc ? "تم قبول طلبك في MSM 🎉" : "بخصوص طلبك في MSM", body);
  return { ok: true, status: r.status, phone: r.phone, notified };
}

const confirmPage = async (url) => {
  const id = url.searchParams.get("id"), t = url.searchParams.get("t"), a = url.searchParams.get("a") === "reject" ? "reject" : "accept";
  const env = url.env, r = id && (await load(env, id, t));
  if (!r) return page("<h1>الرابط غير صالح</h1>");
  if (r.status !== "pending") return page("<h1>تم اتخاذ القرار مسبقاً</h1><p>طلب «" + esc(r.shop) + "»: <b>" + (r.status === "accepted" ? "مقبول" : "مرفوض") + "</b></p>");
  const acc = a === "accept";
  return page("<h1>" + (acc ? "قبول" : "رفض") + " طلب الانضمام؟</h1><p>المتجر: <b>" + esc(r.shop) + "</b><br>صاحب المتجر: " + esc(r.owner) + '</p><button id="go" style="background:' + (acc ? "#1f8a70" : "#e8576b") + '">' + (acc ? "تأكيد القبول (Accept)" : "تأكيد الرفض (Reject)") + '</button><div id="msg"></div><script>var q=new URLSearchParams(location.search);document.getElementById("go").onclick=function(){var b=this;b.disabled=true;fetch(location.origin+location.pathname,{method:"POST",headers:{"Content-Type":"text/plain"},body:JSON.stringify({op:"decide",id:q.get("id"),t:q.get("t"),a:q.get("a")})}).then(function(r){return r.json()}).then(function(r){if(!r.ok)throw 0;b.style.display="none";var m=document.getElementById("msg"),n=r.already?"":(r.notified?"<p>أُرسل إشعار لصاحب المتجر على بريده.</p>":"<p>لم يُرسل إشعار بالبريد، أبلغ صاحب المتجر على هاتفه: <b dir=ltr>"+String(r.phone).replace(/[<>&]/g,"")+"</b></p>");m.innerHTML=r.already?"<h2>تم اتخاذ القرار مسبقاً</h2>":(r.status==="accepted"?"<h2>تم قبول الطلب ✅</h2>":"<h2>تم تسجيل الطلب كمرفوض</h2>")+n}).catch(function(){b.disabled=false;document.getElementById("msg").innerHTML="<h2>تعذّر التنفيذ، حاول مرة أخرى</h2>"})}</script>');
};


// ======== الحسابات والمتاجر والمنتجات والطلبات (مخزنة في KV) ========
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
const pbk = async (pw, salt) => { const k = await crypto.subtle.importKey("raw", enc.encode(pw), "PBKDF2", false, ["deriveBits"]); return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: enc.encode(salt), iterations: 10000 }, k, 256)); };
const rnd = () => crypto.randomUUID().replace(/-/g, "");
const getJ = async (env, k, d) => { const v = await env.KV.get(k); return v ? JSON.parse(v) : d; };
const putJ = (env, k, v) => env.KV.put(k, JSON.stringify(v));
const clean = (s, n) => String(s ?? "").trim().slice(0, n);
const CATS = ["c1", "c2", "c3", "c4", "c5", "c6"], MODES = ["pickup", "delivery", "both"];
const bidOf = async (email) => "b_" + (await sha(email)).slice(0, 12);
async function hit(env, key, max, ttl) { const n = parseInt((await env.KV.get(key)) || "0", 10); if (n >= max) return false; await env.KV.put(key, String(n + 1), { expirationTtl: ttl }); return true; }
async function newSession(env, email) { const tok = rnd() + rnd(); await env.KV.put("s:" + (await sha(tok)), email, { expirationTtl: 2592000 }); return tok; }
const who = async (env, b) => (b.tok ? env.KV.get("s:" + (await sha(String(b.tok)))) : null);
async function myBrand(env, email) { const bs = await getJ(env, "brands", []); return [bs, bs.find((x) => x.owner === email)]; }
async function saveImg(env, data, origin) { if (typeof data !== "string" || !/^data:image\/(jpeg|png|webp);base64,/.test(data) || data.length > 250000) return null; const id = rnd(); await env.KV.put("img:" + id, data); return origin + "?img=" + id; }
async function ensureBrand(env, r) {
  const bs = await getJ(env, "brands", []), id = await bidOf(r.email);
  if (bs.find((x) => x.id === id)) return;
  bs.push({ id, owner: r.email, name: r.shop, cat: CATS.includes(r.catKey) ? r.catKey : "c6", emoji: "🛍️", desc: r.desc, mode: MODES.includes(r.modeKey) ? r.modeKey : "pickup", fee: Number(r.fee) || 0, img: "" });
  await putJ(env, "brands", bs);
}

const no = (e) => ({ ok: false, error: e });

async function api(b, env, o) {
  const op = b.op, bad = no("invalid");
  if (op === "register") {
    const email = clean(b.email, 160).toLowerCase(), name = clean(b.name, 80), pw = String(b.password || "");
    if (!name || !/^\S+@\S+\.\S+$/.test(email) || pw.length < 6 || pw.length > 100) return bad;
    if (!(await hit(env, "rg:" + o.ip, 20, 3600))) return no("rate");
    if (await env.KV.get("u:" + email)) return no("exists");
    const salt = rnd();
    await putJ(env, "u:" + email, { name, salt, hash: await pbk(pw, salt) });
    return { ok: true, tok: await newSession(env, email), user: { name, email } };
  }
  if (op === "login") {
    const email = clean(b.email, 160).toLowerCase(), u = await getJ(env, "u:" + email, null);
    if (!(await hit(env, "lg:" + email, 10, 600))) return no("rate");
    if (!u || (await pbk(String(b.password || ""), u.salt)) !== u.hash) return no("bad");
    return { ok: true, tok: await newSession(env, email), user: { name: u.name, email } };
  }
  const email = await who(env, b);
  if (op === "brands") { const bs = await getJ(env, "brands", []); return { ok: true, brands: bs.map(({ owner, ...x }) => ({ ...x, mine: !!email && owner === email })) }; }
  if (op === "products") return /^b_[a-f0-9]{12}$/.test(String(b.brand)) ? { ok: true, products: await getJ(env, "p:" + b.brand, []) } : bad;
  if (!email) return no("auth");
  if (op === "me") { const u = await getJ(env, "u:" + email, null); return u ? { ok: true, user: { name: u.name, email } } : no("auth"); }
  if (op === "logout") { await env.KV.delete("s:" + (await sha(String(b.tok)))); return { ok: true }; }
  if (op === "order") {
    const brand = (await getJ(env, "brands", [])).find((x) => x.id === b.brand);
    if (!brand) return no("nobrand");
    if (!(await hit(env, "od:" + email, 30, 3600))) return no("rate");
    const ps = await getJ(env, "p:" + brand.id, []), items = [];
    for (const i of (Array.isArray(b.items) ? b.items : []).slice(0, 50)) {
      const p = ps.find((x) => x.id === i.id), q = Math.floor(Number(i.q));
      if (!p || !(q >= 1 && q <= 50)) return bad;
      items.push({ name: p.name, price: p.price, q });
    }
    const mode = b.mode === "delivery" ? "delivery" : "pickup";
    if (!items.length || (brand.mode === "pickup" && mode === "delivery") || (brand.mode === "delivery" && mode === "pickup")) return bad;
    const name = clean(b.name, 80), phone = clean(b.phone, 30), addr = clean(b.addr, 300);
    if (!name || !phone || (mode === "delivery" && !addr)) return bad;
    const total = Math.round((items.reduce((s, i) => s + i.price * i.q, 0) + (mode === "delivery" ? Number(brand.fee) || 0 : 0)) * 1000) / 1000;
    const t = Date.now(), id = "o" + t + rnd().slice(0, 6);
    const order = { id, no: 1000 + Math.floor(Math.random() * 9000), b: brand.id, uid: email, items, mode, name, phone, addr, note: clean(b.note, 300), total, status: "new", t };
    await putJ(env, "o:" + brand.id + ":" + id, order);
    const uo = await getJ(env, "uo:" + email, []); uo.push({ b: brand.id, id });
    await putJ(env, "uo:" + email, uo.slice(-100));
    return { ok: true, order };
  }
  if (op === "myOrders") {
    const uo = (await getJ(env, "uo:" + email, [])).slice(-50);
    const os = (await Promise.all(uo.map((x) => getJ(env, "o:" + x.b + ":" + x.id, null)))).filter(Boolean);
    return { ok: true, orders: os.sort((a, c) => c.t - a.t) };
  }
  // ما بعد هذا السطر: لأصحاب المتاجر المقبولين فقط
  const [bs, br] = await myBrand(env, email);
  if (!br) return no("forbidden");
  if (op === "brandOrders") {
    const ks = (await env.KV.list({ prefix: "o:" + br.id + ":" })).keys.slice(-100);
    const os = (await Promise.all(ks.map((k) => getJ(env, k.name, null)))).filter(Boolean);
    return { ok: true, orders: os.sort((a, c) => c.t - a.t) };
  }
  if (op === "setStatus") {
    const id = String(b.id || "");
    if (!/^o\d+[a-f0-9]{6}$/.test(id)) return bad;
    const od = await getJ(env, "o:" + br.id + ":" + id, null); if (!od) return no("notfound");
    if (!({ new: ["accepted", "rej"], accepted: ["ready"], ready: ["done"] }[od.status] || []).includes(b.status)) return bad;
    od.status = b.status; await putJ(env, "o:" + br.id + ":" + id, od);
    return { ok: true };
  }
  if (op === "saveBrand") {
    br.name = clean(b.name, 120) || br.name; if (CATS.includes(b.cat)) br.cat = b.cat;
    br.desc = clean(b.desc, 1000); if (MODES.includes(b.mode)) br.mode = b.mode;
    br.fee = Math.min(1000, Math.max(0, Number(b.fee) || 0)); br.emoji = clean(b.emoji, 8) || "🛍️";
    if (b.img) { const u = await saveImg(env, b.img, o.origin); if (!u) return no("image"); br.img = u; }
    await putJ(env, "brands", bs); return { ok: true };
  }
  if (op === "addProduct") {
    const ps = await getJ(env, "p:" + br.id, []), price = Number(b.price), name = clean(b.name, 120);
    if (ps.length >= 200 || !name || !(price >= 0) || price > 100000) return bad;
    const p = { id: "p" + rnd().slice(0, 12), b: br.id, name, price: Math.round(price * 1000) / 1000, emoji: clean(b.emoji, 8) || "🎁", desc: clean(b.desc, 500), img: "" };
    if (b.img) { const u = await saveImg(env, b.img, o.origin); if (!u) return no("image"); p.img = u; }
    ps.push(p); await putJ(env, "p:" + br.id, ps); return { ok: true };
  }
  if (op === "delProduct") { const ps = await getJ(env, "p:" + br.id, []); await putJ(env, "p:" + br.id, ps.filter((x) => x.id !== b.id)); return { ok: true }; }
  return no("op");
}

export default {
  async fetch(req, env) {
    const cors = { "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*", "Access-Control-Allow-Headers": "content-type", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
    const json = (o) => new Response(JSON.stringify(o), { headers: { ...cors, "content-type": "application/json" } });
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(req.url); url.env = env;
    if (req.method === "GET") {
      const im = url.searchParams.get("img");
      if (im) {
        const d = /^[a-f0-9]{32}$/.test(im) && (await env.KV.get("img:" + im));
        if (!d) return new Response("not found", { status: 404 });
        const [h, b64] = d.split(",");
        return new Response(Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)), { headers: { "content-type": h.slice(5, h.indexOf(";")), "cache-control": "public, max-age=86400" } });
      }
      return confirmPage(url);
    }
    let b; try { b = JSON.parse(await req.text()); } catch (e) { return json({ ok: false, error: "bad" }); }
    const origin = url.origin + url.pathname;
    try {
      if (b.op === "submit") return json(await submit(b, env, origin));
      if (b.op === "status") return json(await status(b, env));
      if (b.op === "decide") return json(await decide(b, env));
      return json(await api(b, env, { origin, ip: req.headers.get("cf-connecting-ip") || "x" }));
    } catch (e) { return json({ ok: false, error: "server" }); }
  },
};
